package net.sf.opensftp.interceptor;

import java.lang.reflect.Method;
import java.util.Map;
import net.sf.opensftp.SftpResult;

public class MonitoringInterceptor implements Interceptor {

	
	public void afterMethod(Method method, Object[] args, SftpResult result) {
		// TODO Auto-generated method stub
		
	}

	public void beforeMethod(Method method, Object[] args) {
		// TODO Auto-generated method stub
		
	}


}
